
# Family Support App

Um aplicativo React Native para ajudar famílias durante o período pós-parto.

## Funcionalidades
- Lista de compras com persistência local (SQLite)
- Notificações em tempo real usando Firebase
- Testes automatizados com Jest
