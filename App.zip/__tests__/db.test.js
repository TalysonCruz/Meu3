
import * as SQLite from "expo-sqlite";

describe("Banco de Dados SQLite", () => {
  let db;

  beforeAll(() => {
    db = SQLite.openDatabase("test.db");
  });

  afterEach(() => {
    db.transaction((tx) => {
      tx.executeSql("DELETE FROM items;");
    });
  });

  it("deve criar a tabela de itens", (done) => {
    db.transaction((tx) => {
      tx.executeSql(
        "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT);",
        [],
        () => done(),
        (_, error) => {
          throw new Error("Erro ao criar tabela: " + error.message);
        }
      );
    });
  });

  it("deve adicionar um item ao banco", (done) => {
    db.transaction((tx) => {
      tx.executeSql(
        "INSERT INTO items (name) VALUES (?);",
        ["Fraldas"],
        () => {
          tx.executeSql("SELECT * FROM items;", [], (_, { rows }) => {
            expect(rows.length).toBe(1);
            expect(rows._array[0].name).toBe("Fraldas");
            done();
          });
        }
      );
    });
  });
});
