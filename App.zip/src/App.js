
import React, { useEffect } from "react";
import { View, Text } from "react-native";
import { requestNotificationPermission, setupNotificationListeners } from "./services/FirebaseService";

export default function App() {
  useEffect(() => {
    requestNotificationPermission();
    setupNotificationListeners();
  }, []);

  return (
    <View>
      <Text>App com suporte a notificações!</Text>
    </View>
  );
}
