
import messaging from '@react-native-firebase/messaging';
import { Alert } from 'react-native';

export async function requestNotificationPermission() {
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

  if (enabled) {
    console.log('Permissão concedida para notificações:', authStatus);
  } else {
    Alert.alert('Permissão negada', 'Você precisa ativar notificações para este app.');
  }
}

export async function getDeviceToken() {
  try {
    const token = await messaging().getToken();
    console.log('Token do dispositivo:', token);
    return token;
  } catch (error) {
    console.error('Erro ao obter token do dispositivo:', error);
  }
}

export function setupNotificationListeners() {
  messaging().onMessage(async (remoteMessage) => {
    Alert.alert(
      'Nova mensagem!',
      remoteMessage.notification?.body || 'Você recebeu uma nova notificação.'
    );
  });

  messaging().setBackgroundMessageHandler(async (remoteMessage) => {
    console.log('Notificação em segundo plano:', remoteMessage);
  });
}
