
import * as SQLite from "expo-sqlite";

const db = SQLite.openDatabase("family_support.db");

export const initializeDatabase = () => {
  db.transaction((tx) => {
    tx.executeSql(
      "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT);"
    );
  });
};

export const addItem = (name, callback) => {
  db.transaction((tx) => {
    tx.executeSql(
      "INSERT INTO items (name) VALUES (?);",
      [name],
      (_, result) => callback(null, result),
      (_, error) => callback(error)
    );
  });
};

export const fetchItems = (callback) => {
  db.transaction((tx) => {
    tx.executeSql(
      "SELECT * FROM items;",
      [],
      (_, { rows }) => callback(null, rows._array),
      (_, error) => callback(error)
    );
  });
};
