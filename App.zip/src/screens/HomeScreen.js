
import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Button, FlatList, Alert } from "react-native";
import { initializeDatabase, addItem, fetchItems } from "../database/SQLiteConfig";

export default function HomeScreen() {
  const [item, setItem] = useState("");
  const [items, setItems] = useState([]);

  useEffect(() => {
    initializeDatabase();
    loadItems();
  }, []);

  const loadItems = () => {
    fetchItems((error, data) => {
      if (error) {
        console.error("Erro ao carregar itens:", error);
      } else {
        setItems(data);
      }
    });
  };

  const handleAddItem = () => {
    if (!item.trim()) {
      Alert.alert("Erro", "O item não pode estar vazio.");
      return;
    }
    addItem(item, (error) => {
      if (error) {
        console.error("Erro ao adicionar item:", error);
      } else {
        setItem("");
        loadItems();
      }
    });
  };

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: "bold", marginBottom: 20 }}>Lista de Compras</Text>
      <TextInput
        placeholder="Adicionar item..."
        value={item}
        onChangeText={setItem}
        style={{
          borderWidth: 1,
          borderColor: "#ccc",
          padding: 10,
          marginBottom: 10,
        }}
      />
      <Button title="Adicionar" onPress={handleAddItem} />
      <FlatList
        data={items}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              padding: 10,
              borderBottomWidth: 1,
              borderColor: "#eee",
            }}
          >
            <Text>{item.name}</Text>
          </View>
        )}
      />
    </View>
  );
}
